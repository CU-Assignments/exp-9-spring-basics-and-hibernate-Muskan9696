package util;

import java.sql.Types;
import org.hibernate.dialect.Dialect;
import org.hibernate.dialect.function.StandardSQLFunction;
import org.hibernate.type.StringType;

public class SQLiteDialect extends Dialect {

    public SQLiteDialect() {
        super();
        registerColumnType(Types.INTEGER, "integer");
        registerColumnType(Types.VARCHAR, "varchar");
        registerColumnType(Types.FLOAT, "float");
        registerColumnType(Types.DOUBLE, "double");
        registerColumnType(Types.BOOLEAN, "boolean");

        registerFunction("lower", new StandardSQLFunction("lower", new StringType()));
    }

    @Override
    public boolean hasAlterTable() { return false; }

    @Override
    public boolean dropConstraints() { return false; }

    @Override
    public boolean supportsIfExistsBeforeTableName() { return true; }

    @Override
    public boolean supportsCascadeDelete() { return false; }
}
